#include "HeaderFile.h"
double ComputeAlphaPiU_F1(double x, double y)
{
	double alpha_piU = sin(M_PI * x) * sin(M_PI * y);
	return alpha_piU;
}